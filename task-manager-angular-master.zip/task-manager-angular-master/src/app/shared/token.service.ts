import { Angular2TokenService } from "angular2-token";

export class TokenService extends Angular2TokenService {
  
}