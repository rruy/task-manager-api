class Api::V1::BaseController < ApplicationController
  include Authenticable
end