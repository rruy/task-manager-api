import { NSAngular2TokenService } from "./ns-angular2-token/ns-angular2-token.service";

export class TokenService extends NSAngular2TokenService {
  
}